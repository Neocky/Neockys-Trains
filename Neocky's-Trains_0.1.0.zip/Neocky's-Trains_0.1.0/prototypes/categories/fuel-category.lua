data:extend({
	{
	type = "fuel-category",
	name = "nt-battery",
	}
})