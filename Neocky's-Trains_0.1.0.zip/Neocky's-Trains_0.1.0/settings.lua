data:extend({
	{
		type = "bool-setting",
		name = "setting-train-electric",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "setting-train-nuclear",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "setting-train-fusion",
		setting_type = "startup",
		default_value = true,
	}
})